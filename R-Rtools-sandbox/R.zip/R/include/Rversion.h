/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 197121
#define R_NICK "World-Famous Astronaut"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "3"
#define R_MINOR  "2.1"
#define R_STATUS ""
#define R_YEAR   "2015"
#define R_MONTH  "06"
#define R_DAY    "18"
#define R_SVN_REVISION 68531
#define R_FILEVERSION    3,21,68531,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
